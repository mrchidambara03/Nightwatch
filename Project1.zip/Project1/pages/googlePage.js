module.exports = function (browser) {
  this.goToGoogle = function() {
        browser
            .url('http://google.com')
            .waitForElementVisible('body', 1000);
            return browser;
    };
};